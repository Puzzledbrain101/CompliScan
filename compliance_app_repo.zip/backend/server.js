// server.js - sample Express backend for OCR/scraping pipeline (demo)
// NOTE: This is a starter example. Replace mock parsing with real OCR / scraping.
const express = require('express');
const multer = require('multer');
const axios = require('axios');
const cheerio = require('cheerio');
const upload = multer({ dest: 'uploads/' });
const app = express();
app.use(express.json());

// Simple scrape function (best-effort)
async function scrapeProduct(url) {
  const { data } = await axios.get(url, { timeout: 10000 });
  const $ = cheerio.load(data);
  // naive extraction - adapt per site
  const product_name = $('h1').first().text().trim() || null;
  const price = $('[class*="price"]').first().text().trim() || null;
  const net_quantity = $('span:contains("g"), span:contains("kg"), span:contains("ml"), span:contains("l")').first().text().trim() || null;
  const manufacturer = $('meta[name="manufacturer"]').attr('content') || null;
  return {
    product_name,
    MRP: price,
    net_quantity,
    manufacturer,
    country_of_origin: null
  };
}

app.post('/api/check', upload.single('image'), async (req, res) => {
  try {
    const imageFile = req.file;
    const { url } = req.body;

    let parsed;
    if (url) {
      parsed = await scrapeProduct(url);
    } else if (imageFile) {
      // In production: run Tesseract or Google Vision on imageFile.path
      // For demo we return a mocked parsed object
      parsed = {
        product_name: 'Demo from image',
        MRP: '₹199',
        net_quantity: '100g',
        manufacturer: 'Demo Manufacturer',
        country_of_origin: 'India',
        _ocr_confidence: 0.9,
        _image_resolution: { width: 1200, height: 900 }
      };
    } else {
      return res.status(400).json({ error: 'Provide image file or url' });
    }

    // Simple rule engine
    const required = ['product_name','MRP','manufacturer','net_quantity','country_of_origin'];
    const violations = [];
    required.forEach(k => { if (!parsed[k]) violations.push(`${k} missing`); });

    const reasons = [];
    if (parsed._ocr_confidence && parsed._ocr_confidence < 0.6) reasons.push('Low OCR confidence');
    if (parsed._image_resolution && (parsed._image_resolution.width < 400 || parsed._image_resolution.height < 300)) reasons.push('Low resolution');

    const score = Math.max(0, Math.round((1 - violations.length / required.length - (reasons.length * 0.05)) * 100));
    const status = violations.length === 0 && reasons.length === 0 ? 'approved' : (reasons.length > 0 && violations.length === 0 ? 'rejected' : 'failed');

    const log = {
      id: `check_${Date.now()}`,
      parsed,
      compliance_score: score,
      status,
      violations,
      reasons,
      timestamp: new Date().toISOString()
    };

    // In production save to DB
    return res.json(log);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('Server running on port', PORT));
