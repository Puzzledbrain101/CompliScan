// File: src/App.jsx
// ComplianceApp component (single-file demo). Replace mockParseInput with real API calls in production.
import React, { useState, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, BarChart, Bar } from 'recharts';

export default function ComplianceApp() {
  const [view, setView] = useState('seller'); // seller | backend
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);
  const [logs, setLogs] = useState([]);
  const fileInputRef = useRef();

  // Mock rule engine run on parsed fields
  function runRuleEngine(parsed) {
    const required = ['product_name', 'MRP', 'manufacturer', 'net_quantity', 'country_of_origin'];
    const violations = [];
    required.forEach((k) => {
      if (!parsed[k]) violations.push(`${k} missing`);
    });

    // Simple OCR quality checks
    const reasons = [];
    if (parsed._ocr_confidence && parsed._ocr_confidence < 0.6) reasons.push('Low OCR confidence (text unclear)');
    if (parsed._image_resolution && (parsed._image_resolution.width < 400 || parsed._image_resolution.height < 300)) reasons.push('Low resolution image');

    const score = Math.max(0, Math.round((1 - violations.length / required.length - (reasons.length * 0.05)) * 100));

    const status = violations.length === 0 && reasons.length === 0 ? 'approved' : (reasons.length > 0 && violations.length === 0 ? 'rejected' : 'failed');

    return {
      compliance_score: score,
      violations,
      reasons,
      status,
    };
  }

  // Mock OCR / Scraper that returns parsed fields for demo
  async function mockParseInput({ type, file, url }) {
    // In a real backend this would call OCR (Tesseract / Google Vision) or scrape the URL
    await new Promise((r) => setTimeout(r, 800)); // simulate latency

    if (type === 'url') {
      // fake scraped content depending on url
      if (!url || !url.startsWith('http')) throw new Error('Invalid URL');
      // For demo, treat urls containing "partial" as missing fields
      if (url.includes('partial')) {
        return {
          product_name: 'Demo Shampoo (partial)',
          MRP: null,
          manufacturer: 'DemoLabs Pvt Ltd',
          net_quantity: null,
          country_of_origin: null,
          _ocr_confidence: 0.95,
          _image_resolution: { width: 1024, height: 768 },
        };
      }
      // good url
      return {
        product_name: 'Demo Face Cream',
        MRP: '₹199',
        manufacturer: 'DemoLabs Pvt Ltd',
        net_quantity: '50g',
        country_of_origin: 'India',
        _ocr_confidence: 0.96,
        _image_resolution: { width: 1200, height: 900 },
      };
    }

    // image path
    if (type === 'image') {
      // If file name contains "blurry" simulate bad OCR
      const name = file && file.name ? file.name.toLowerCase() : '';
      if (name.includes('blurry')) {
        return {
          product_name: null,
          MRP: null,
          manufacturer: null,
          net_quantity: null,
          country_of_origin: null,
          _ocr_confidence: 0.3,
          _image_resolution: { width: 300, height: 200 },
        };
      }

      // otherwise return partial or full depending on name
      if (name.includes('partial')) {
        return {
          product_name: 'Demo Soap (img)',
          MRP: '₹49',
          manufacturer: null,
          net_quantity: '75g',
          country_of_origin: null,
          _ocr_confidence: 0.82,
          _image_resolution: { width: 800, height: 600 },
        };
      }

      return {
        product_name: 'Demo Lotion (img)',
        MRP: '₹299',
        manufacturer: 'SkinCo Labs',
        net_quantity: '100ml',
        country_of_origin: 'India',
        _ocr_confidence: 0.9,
        _image_resolution: { width: 1200, height: 900 },
      };
    }

    throw new Error('Unsupported type');
  }

  async function handleSubmit(event) {
    event?.preventDefault?.();
    setSubmitting(true);
    setResult(null);

    try {
      const file = fileInputRef.current?.files?.[0];
      const url = event?.target?.url?.value?.trim();

      if (!file && !url) {
        alert('Please upload an image or paste a URL');
        setSubmitting(false);
        return;
      }

      const type = file ? 'image' : 'url';
      const parsed = await mockParseInput({ type, file, url });
      const engine = runRuleEngine(parsed);

      const log = {
        id: `check_${Date.now()}`,
        submitted_by: 'seller_demo',
        product_preview: parsed.product_name || 'Unknown product',
        input_type: type,
        parsed,
        ...engine,
        timestamp: new Date().toISOString(),
        highlight: engine.status === 'rejected' || engine.compliance_score < 100,
      };

      setResult(log);
      setLogs((s) => [log, ...s]);

    } catch (err) {
      setResult({ status: 'rejected', reason: err.message, violations: [], compliance_score: 0 });
    } finally {
      setSubmitting(false);
    }
  }

  // Simple visual helpers
  function statusColor(status) {
    if (status === 'approved') return 'bg-green-100 text-green-800';
    if (status === 'failed') return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  }

  // Small analytics
  const trendData = logs.slice(0, 12).reverse().map((l, i) => ({ x: i + 1, compliance: l.compliance_score }));
  const brandViolations = [{ brand: 'DemoLabs', violations: logs.filter(l => l.parsed?.manufacturer?.toLowerCase()?.includes('demolabs')).length }, { brand: 'SkinCo Labs', violations: logs.filter(l => l.parsed?.manufacturer?.toLowerCase()?.includes('skinco')).length }];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <header className="max-w-6xl mx-auto mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Product Compliance — Demo</h1>
        <div className="space-x-2">
          <button onClick={() => setView('seller')} className={`px-4 py-2 rounded ${view==='seller'?'bg-blue-600 text-white':'bg-white border'}`}>Seller View</button>
          <button onClick={() => setView('backend')} className={`px-4 py-2 rounded ${view==='backend'?'bg-blue-600 text-white':'bg-white border'}`}>Compliance Panel</button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left column: form or filters */}
        <section className="col-span-1 md:col-span-1 bg-white p-4 rounded shadow">
          {view === 'seller' ? (
            <form onSubmit={handleSubmit}>
              <h2 className="font-semibold mb-2">Upload product image or paste product URL</h2>

              <div className="mb-3">
                <label className="block text-sm font-medium">Image</label>
                <input ref={fileInputRef} type="file" accept="image/*" className="mt-1 block w-full" />
              </div>

              <div className="mb-3">
                <label className="block text-sm font-medium">Or product URL</label>
                <input name="url" type="text" placeholder="https://..." className="mt-1 block w-full border rounded p-2" />
              </div>

              <div className="flex items-center gap-2">
                <button type="submit" disabled={submitting} className="px-4 py-2 bg-blue-600 text-white rounded">{submitting? 'Checking...' : 'Check Compliance'}</button>
                <button type="button" onClick={() => { fileInputRef.current.value = null; }} className="px-3 py-2 border rounded">Clear</button>
              </div>

              {result && (
                <div className={`mt-4 p-3 rounded ${statusColor(result.status)}`}>
                  <div className="flex items-center justify-between">
                    <strong>Status: {result.status?.toUpperCase()}</strong>
                    <span>Score: {result.compliance_score}%</span>
                  </div>
                  {result.violations?.length > 0 && (
                    <div className="mt-2 text-sm">
                      <strong>Violations:</strong>
                      <ul className="list-disc list-inside">
                        {result.violations.map((v, i) => <li key={i}>{v}</li>)}
                      </ul>
                    </div>
                  )}
                  {result.reasons?.length > 0 && (
                    <div className="mt-2 text-sm">
                      <strong>Rejection reasons:</strong>
                      <ul className="list-disc list-inside">
                        {result.reasons.map((r, i) => <li key={i}>{r}</li>)}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </form>
          ) : (
            <div>
              <h2 className="font-semibold mb-2">Filters</h2>
              <p className="text-sm text-gray-600">Filter the backend panel by status, date, seller, etc. (demo-only UI)</p>
            </div>
          )}
        </section>

        {/* Middle column: recent result or analytics */}
        <section className="col-span-2 md:col-span-2">
          {view === 'seller' ? (
            <div className="bg-white p-4 rounded shadow mb-6">
              <h3 className="font-semibold mb-3">Latest check</h3>
              {result ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <table className="w-full text-sm">
                      <tbody>
                        <tr><td className="font-medium">Product</td><td>{result.parsed.product_name || '—'}</td></tr>
                        <tr><td className="font-medium">MRP</td><td>{result.parsed.MRP || '—'}</td></tr>
                        <tr><td className="font-medium">Manufacturer</td><td>{result.parsed.manufacturer || '—'}</td></tr>
                        <tr><td className="font-medium">Net quantity</td><td>{result.parsed.net_quantity || '—'}</td></tr>
                        <tr><td className="font-medium">Country of origin</td><td>{result.parsed.country_of_origin || '—'}</td></tr>
                        <tr><td className="font-medium">OCR confidence</td><td>{result.parsed._ocr_confidence ?? '—'}</td></tr>
                      </tbody>
                    </table>
                  </div>

                  <div>
                    <h4 className="font-medium">Action</h4>
                    <p className="text-sm text-gray-600">You can either accept this product, re-upload a clearer image, or send to backend for manual review.</p>
                    <div className="mt-3 space-x-2">
                      <button className="px-3 py-2 bg-green-600 text-white rounded">Accept</button>
                      <button className="px-3 py-2 bg-yellow-500 text-white rounded">Request clearer image</button>
                      <button className="px-3 py-2 bg-red-600 text-white rounded">Escalate to compliance</button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-sm text-gray-600">No checks yet. Upload an image or paste an URL to start.</div>
              )}
            </div>
          ) : null}

# write the frontend files
